package com.sample;

public class Product {

	 private String name;
	 private double price;
	 private int quantity;
	 
	 //This is the user defined constructor
	 Product(String name, double price, int quantity){
		 this.name = name;
		 this.price = price;
		 this.quantity = quantity;
	 }
	 
	 //Getters or the accessor methods
	 public String getName() {
	    return name;
	 }
	    
	 public double getPrice() {
	     return price;
	 }
	    
	public int getQuantity() {
		 return quantity;
	 }
	
	//Method that will give the total ammount of a certain product
	public double totalAmmount() {
		return quantity * price;
	}
	
}
