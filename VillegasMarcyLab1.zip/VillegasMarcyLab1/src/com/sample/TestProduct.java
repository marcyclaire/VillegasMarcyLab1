package com.sample;

public class TestProduct {

	public static void main(String[] args) {
		
		//object1
		Product product1 = new Product("Laptop",25000,2);
		System.out.println("These are the properties of the product you want to buy:");
		System.out.println("Name: " + product1.getName());
		System.out.println("Price: " + product1.getPrice());
		System.out.println("Quantity: " + product1.getQuantity());
		System.out.println("Total ammount for the product " + product1.getName() + ": " + product1.totalAmmount());
		
		System.out.println();
		
		//object2
		Product product2 = new Product("Phone",5000,3);
		System.out.println("These are the properties of the product you want to buy:");
		System.out.println("Name: " + product2.getName());
		System.out.println("Price: " + product2.getPrice());
		System.out.println("Quantity: " + product2.getQuantity());
		System.out.println("Total ammount for the product " + product2.getName() + ": " + product1.totalAmmount());
	} 
	
}